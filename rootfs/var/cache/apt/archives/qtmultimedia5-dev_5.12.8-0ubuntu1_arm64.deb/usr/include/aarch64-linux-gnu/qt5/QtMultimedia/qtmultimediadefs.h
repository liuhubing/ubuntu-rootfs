#ifndef DEPRECATED_HEADER_QtMultimedia_qtmultimediadefs_h
#define DEPRECATED_HEADER_QtMultimedia_qtmultimediadefs_h
#if defined(__GNUC__)
#  warning Header <QtMultimedia/qtmultimediadefs.h> is deprecated. Please include <QtMultimedia/qtmultimediaglobal.h> instead.
#elif defined(_MSC_VER)
#  pragma message ("Header <QtMultimedia/qtmultimediadefs.h> is deprecated. Please include <QtMultimedia/qtmultimediaglobal.h> instead.")
#endif
#include <QtMultimedia/qtmultimediaglobal.h>
#if 0
#pragma qt_no_master_include
#endif
#endif
