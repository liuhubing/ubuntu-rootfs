The *.txt files, if available, contain helper to override some of the errors messages.
Please visit https://github.com/google/sanitizers/wiki/AddressSanitizer for help
