"""This module holds the global configuration for the parser ``MdParserConfig``."""
