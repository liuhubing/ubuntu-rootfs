Built-in Utilities
==================

.. automodule:: pyopencl.tools
