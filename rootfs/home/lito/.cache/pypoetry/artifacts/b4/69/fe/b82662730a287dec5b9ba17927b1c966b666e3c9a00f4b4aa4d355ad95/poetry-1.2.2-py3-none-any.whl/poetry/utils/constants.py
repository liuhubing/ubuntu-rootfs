from __future__ import annotations


# Timeout for HTTP requests using the requests library.
REQUESTS_TIMEOUT = 15
